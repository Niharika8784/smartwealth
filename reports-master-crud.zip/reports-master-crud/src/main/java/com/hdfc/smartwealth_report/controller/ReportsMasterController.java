package com.hdfc.smartwealth_report.controller;

import com.hdfc.smartwealth_report.dto.Response;
import com.hdfc.smartwealth_report.dto.request.ReportsMasterFilterRequestDto;
import com.hdfc.smartwealth_report.dto.request.ReportsMasterRequestDto;
import com.hdfc.smartwealth_report.dto.response.ReportsMasterResponseDto;
import com.hdfc.smartwealth_report.service.ReportsMasterService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST controller for ReportsMaster CRUD.
 *
 * Base path: /api/v1/reports-master
 *
 * ┌────────┬──────────────────────────────────────────────┬──────────────────────────────────┐
 * │ Method │ Path                                         │ Description                      │
 * ├────────┼──────────────────────────────────────────────┼──────────────────────────────────┤
 * │ POST   │ /api/v1/reports-master                       │ Create a new report               │
 * │ GET    │ /api/v1/reports-master                       │ Fetch all (optional filters)      │
 * │ GET    │ /api/v1/reports-master/{id}                  │ Fetch by primary key              │
 * │ GET    │ /api/v1/reports-master/wealthfy/{wId}        │ Fetch by wealthfyReportId         │
 * │ PUT    │ /api/v1/reports-master/{id}                  │ Full update                       │
 * │ DELETE │ /api/v1/reports-master/{id}                  │ Delete                            │
 * └────────┴──────────────────────────────────────────────┴──────────────────────────────────┘
 */
@RestController
@RequestMapping("/api/v1/reports-master")
@RequiredArgsConstructor
@Slf4j
public class ReportsMasterController {

    private final ReportsMasterService reportsMasterService;

    // ── CREATE ────────────────────────────────────────────────────────────────

    /**
     * POST /api/v1/reports-master
     *
     * Request body:
     * {
     *   "wealthfyReportId": 201,
     *   "reportName":       "Summary Report"
     * }
     */
    @PostMapping
    public ResponseEntity<Response<ReportsMasterResponseDto>> createReport(
            @RequestBody ReportsMasterRequestDto requestDto) {

        log.info("POST /api/v1/reports-master | reportName={}", requestDto.getReportName());

        ReportsMasterResponseDto responseDto = reportsMasterService.create(requestDto);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(new Response<>("Report created successfully.", responseDto));
    }

    // ── FETCH ALL (with optional filters) ─────────────────────────────────────

    /**
     * GET /api/v1/reports-master                                → all reports
     * GET /api/v1/reports-master?reportName=summary             → LIKE '%summary%'
     * GET /api/v1/reports-master?wealthfyReportId=201           → exact ID match
     * GET /api/v1/reports-master?reportName=summary&wealthfyReportId=201  → AND both
     */
    @GetMapping
    public ResponseEntity<Response<List<ReportsMasterResponseDto>>> fetchAllReports(
            @RequestParam(required = false) String reportName,
            @RequestParam(required = false) Long   wealthfyReportId) {

        log.info("GET all reports | reportName={} wealthfyReportId={}", reportName, wealthfyReportId);

        ReportsMasterFilterRequestDto filterDto =
                new ReportsMasterFilterRequestDto(reportName, wealthfyReportId);

        List<ReportsMasterResponseDto> responseDtos = reportsMasterService.fetchAllReports(filterDto);

        if (responseDtos.isEmpty()) {
            return ResponseEntity.ok(new Response<>("No report found.", null));
        }

        return ResponseEntity.ok(
                new Response<>("Fetched all reports successfully.", responseDtos));
    }

    // ── FETCH BY ID ───────────────────────────────────────────────────────────

    /**
     * GET /api/v1/reports-master/{id}
     */
    @GetMapping("/{id}")
    public ResponseEntity<Response<ReportsMasterResponseDto>> fetchReportById(
            @PathVariable Long id) {

        log.info("GET report by id={}", id);

        ReportsMasterResponseDto responseDto = reportsMasterService.fetchById(id);

        return ResponseEntity.ok(
                new Response<>("Fetched report successfully.", responseDto));
    }

    // ── FETCH BY WEALTHFY REPORT ID ───────────────────────────────────────────

    /**
     * GET /api/v1/reports-master/wealthfy/{wealthfyReportId}
     */
    @GetMapping("/wealthfy/{wealthfyReportId}")
    public ResponseEntity<Response<ReportsMasterResponseDto>> fetchReportByWealthfyId(
            @PathVariable Long wealthfyReportId) {

        log.info("GET report by wealthfyReportId={}", wealthfyReportId);

        ReportsMasterResponseDto responseDto =
                reportsMasterService.fetchByWealthfyReportId(wealthfyReportId);

        return ResponseEntity.ok(
                new Response<>("Fetched report successfully.", responseDto));
    }

    // ── UPDATE ────────────────────────────────────────────────────────────────

    /**
     * PUT /api/v1/reports-master/{id}
     *
     * Same request body structure as POST.
     * createdTime is preserved; updatedTime is refreshed automatically.
     */
    @PutMapping("/{id}")
    public ResponseEntity<Response<ReportsMasterResponseDto>> updateReport(
            @PathVariable Long id,
            @RequestBody ReportsMasterRequestDto requestDto) {

        log.info("PUT report id={}", id);

        ReportsMasterResponseDto responseDto = reportsMasterService.update(id, requestDto);

        return ResponseEntity.ok(
                new Response<>("Report updated successfully.", responseDto));
    }

    // ── DELETE ────────────────────────────────────────────────────────────────

    /**
     * DELETE /api/v1/reports-master/{id}
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Response<Void>> deleteReport(@PathVariable Long id) {

        log.info("DELETE report id={}", id);

        reportsMasterService.delete(id);

        return ResponseEntity.ok(
                new Response<>("Report deleted successfully.", null));
    }
}
