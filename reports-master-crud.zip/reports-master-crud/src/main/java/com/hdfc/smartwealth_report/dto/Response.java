package com.hdfc.smartwealth_report.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * Organisation-standard response wrapper.
 * Usage: ResponseEntity<Response<T>>
 */
@Data
@AllArgsConstructor
public class Response<T> {

    private String message;
    private T      payload;
}
