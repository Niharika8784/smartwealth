package com.hdfc.smartwealth_report.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Response DTO for ReportsMaster.
 * Returned by all read / create / update endpoints.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReportsMasterResponseDto {

    private Long          id;
    private Long          wealthfyReportId;
    private String        reportName;
    private LocalDateTime createdTime;
    private LocalDateTime updatedTime;
}
