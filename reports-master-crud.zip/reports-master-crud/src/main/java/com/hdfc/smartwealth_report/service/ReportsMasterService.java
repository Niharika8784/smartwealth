package com.hdfc.smartwealth_report.service;

import com.hdfc.smartwealth_report.dto.request.ReportsMasterFilterRequestDto;
import com.hdfc.smartwealth_report.dto.request.ReportsMasterRequestDto;
import com.hdfc.smartwealth_report.dto.response.ReportsMasterResponseDto;

import java.util.List;

public interface ReportsMasterService {

    ReportsMasterResponseDto       create(ReportsMasterRequestDto requestDto);

    List<ReportsMasterResponseDto> fetchAllReports(ReportsMasterFilterRequestDto filterDto);

    ReportsMasterResponseDto       fetchById(Long id);

    ReportsMasterResponseDto       fetchByWealthfyReportId(Long wealthfyReportId);

    ReportsMasterResponseDto       update(Long id, ReportsMasterRequestDto requestDto);

    void                           delete(Long id);
}
