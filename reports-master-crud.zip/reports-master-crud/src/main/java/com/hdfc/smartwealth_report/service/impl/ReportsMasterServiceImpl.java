package com.hdfc.smartwealth_report.service.impl;

import com.hdfc.smartwealth_report.dto.request.ReportsMasterFilterRequestDto;
import com.hdfc.smartwealth_report.dto.request.ReportsMasterRequestDto;
import com.hdfc.smartwealth_report.dto.response.ReportsMasterResponseDto;
import com.hdfc.smartwealth_report.entity.ReportsMaster;
import com.hdfc.smartwealth_report.exception.ResourceNotFoundException;
import com.hdfc.smartwealth_report.mapper.ReportsMasterMapper;
import com.hdfc.smartwealth_report.repository.ReportsMasterRepository;
import com.hdfc.smartwealth_report.service.ReportsMasterService;
import com.hdfc.smartwealth_report.specification.ReportsMasterSpecification;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class ReportsMasterServiceImpl implements ReportsMasterService {

    private final ReportsMasterRepository reportsMasterRepository;
    private final ReportsMasterMapper     reportsMasterMapper;

    // ── CREATE ────────────────────────────────────────────────────────────────

    @Override
    @Transactional
    public ReportsMasterResponseDto create(ReportsMasterRequestDto requestDto) {
        log.info("Creating report | reportName={} wealthfyReportId={}",
                requestDto.getReportName(), requestDto.getWealthfyReportId());

        // ── Master table: both fields are mandatory ────────────────────────────
        if (requestDto.getWealthfyReportId() == null) {
            throw new IllegalArgumentException("Wealthfy report ID must not be null.");
        }

        if (requestDto.getReportName() == null || requestDto.getReportName().trim().isEmpty()) {
            throw new IllegalArgumentException("Report name must not be null or blank.");
        }

        String reportName = requestDto.getReportName().trim();

        // ── Duplicate checks ──────────────────────────────────────────────────
        if (reportsMasterRepository.existsByWealthfyReportId(requestDto.getWealthfyReportId())) {
            throw new IllegalArgumentException(
                    "Report with wealthfyReportId '"
                    + requestDto.getWealthfyReportId() + "' already exists.");
        }

        if (reportsMasterRepository.findByReportName(reportName).isPresent()) {
            throw new IllegalArgumentException(
                    "Report with name '" + reportName + "' already exists.");
        }

        requestDto.setReportName(reportName);

        ReportsMaster saved = reportsMasterRepository.save(reportsMasterMapper.toEntity(requestDto));
        log.info("Report created | id={}", saved.getId());
        return reportsMasterMapper.toResponseDto(saved);
    }

    // ── FETCH ALL (with optional Predicate filters) ───────────────────────────

    @Override
    @Transactional(readOnly = true)
    public List<ReportsMasterResponseDto> fetchAllReports(ReportsMasterFilterRequestDto filterDto) {
        log.info("Fetching reports | reportName={} wealthfyReportId={}",
                filterDto.getReportName(), filterDto.getWealthfyReportId());

        Specification<ReportsMaster> spec = ReportsMasterSpecification.withFilters(
                filterDto.getReportName(),
                filterDto.getWealthfyReportId()
        );

        Sort sort = Sort.by(Sort.Direction.ASC, "reportName");

        List<ReportsMaster> reports = reportsMasterRepository.findAll(spec, sort);
        log.info("Reports found: {}", reports.size());

        return reports.stream()
                .map(reportsMasterMapper::toResponseDto)
                .collect(Collectors.toList());
    }

    // ── FETCH BY ID ───────────────────────────────────────────────────────────

    @Override
    @Transactional(readOnly = true)
    public ReportsMasterResponseDto fetchById(Long id) {
        log.info("Fetching report | id={}", id);
        return reportsMasterMapper.toResponseDto(fetchOrThrow(id));
    }

    // ── FETCH BY WEALTHFY REPORT ID ───────────────────────────────────────────

    @Override
    @Transactional(readOnly = true)
    public ReportsMasterResponseDto fetchByWealthfyReportId(Long wealthfyReportId) {
        log.info("Fetching report | wealthfyReportId={}", wealthfyReportId);
        ReportsMaster entity = reportsMasterRepository.findByWealthfyReportId(wealthfyReportId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Report not found with wealthfyReportId: " + wealthfyReportId));
        return reportsMasterMapper.toResponseDto(entity);
    }

    // ── UPDATE ────────────────────────────────────────────────────────────────

    @Override
    @Transactional
    public ReportsMasterResponseDto update(Long id, ReportsMasterRequestDto requestDto) {
        log.info("Updating report | id={}", id);

        ReportsMaster entity = fetchOrThrow(id);

        // ── Master table: both fields are mandatory on update too ─────────────
        if (requestDto.getWealthfyReportId() == null) {
            throw new IllegalArgumentException("Wealthfy report ID must not be null.");
        }

        if (requestDto.getReportName() == null || requestDto.getReportName().trim().isEmpty()) {
            throw new IllegalArgumentException("Report name must not be null or blank.");
        }

        String reportName = requestDto.getReportName().trim();

        // ── Duplicate name check — exclude self ───────────────────────────────
        reportsMasterRepository.findByReportName(reportName)
                .ifPresent(existing -> {
                    if (!existing.getId().equals(id)) {
                        throw new IllegalArgumentException(
                                "Another report with name '" + reportName + "' already exists.");
                    }
                });

        // ── Duplicate wealthfyReportId check — exclude self ───────────────────
        reportsMasterRepository.findByWealthfyReportId(requestDto.getWealthfyReportId())
                .ifPresent(existing -> {
                    if (!existing.getId().equals(id)) {
                        throw new IllegalArgumentException(
                                "Another report with wealthfyReportId '"
                                + requestDto.getWealthfyReportId() + "' already exists.");
                    }
                });

        requestDto.setReportName(reportName);
        reportsMasterMapper.updateEntity(entity, requestDto);

        ReportsMaster saved = reportsMasterRepository.save(entity);
        log.info("Report updated | id={}", saved.getId());
        return reportsMasterMapper.toResponseDto(saved);
    }

    // ── DELETE ────────────────────────────────────────────────────────────────

    @Override
    @Transactional
    public void delete(Long id) {
        log.info("Deleting report | id={}", id);
        fetchOrThrow(id);
        reportsMasterRepository.deleteById(id);
        log.info("Report deleted | id={}", id);
    }

    // ── Private helper ────────────────────────────────────────────────────────

    private ReportsMaster fetchOrThrow(Long id) {
        return reportsMasterRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("ReportsMaster", id));
    }
}
