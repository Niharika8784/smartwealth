package com.hdfc.smartwealth_report.mapper;

import com.hdfc.smartwealth_report.dto.request.ReportsMasterRequestDto;
import com.hdfc.smartwealth_report.dto.response.ReportsMasterResponseDto;
import com.hdfc.smartwealth_report.entity.ReportsMaster;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Component
public class ReportsMasterMapper {

    // ── Request DTO → new Entity ──────────────────────────────────────────────

    public ReportsMaster toEntity(ReportsMasterRequestDto dto) {
        LocalDateTime now = LocalDateTime.now();
        return ReportsMaster.builder()
                .wealthfyReportId(dto.getWealthfyReportId())
                .reportName(dto.getReportName().trim())
                .createdTime(dto.getCreatedTime() != null ? dto.getCreatedTime() : now)
                .updatedTime(dto.getUpdatedTime() != null ? dto.getUpdatedTime() : now)
                .build();
    }

    // ── Request DTO → update existing Entity ──────────────────────────────────

    /**
     * Applies updated fields onto the existing managed entity.
     * createdTime is NEVER overwritten.
     * updatedTime is always refreshed to now.
     */
    public void updateEntity(ReportsMaster entity, ReportsMasterRequestDto dto) {
        entity.setWealthfyReportId(dto.getWealthfyReportId());
        entity.setReportName(dto.getReportName().trim());
        entity.setUpdatedTime(LocalDateTime.now());
    }

    // ── Entity → Response DTO ─────────────────────────────────────────────────

    public ReportsMasterResponseDto toResponseDto(ReportsMaster entity) {
        return ReportsMasterResponseDto.builder()
                .id(entity.getId())
                .wealthfyReportId(entity.getWealthfyReportId())
                .reportName(entity.getReportName())
                .createdTime(entity.getCreatedTime())
                .updatedTime(entity.getUpdatedTime())
                .build();
    }
}
