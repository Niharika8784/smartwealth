package com.hdfc.smartwealth_report.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Optional filter DTO for fetching reports.
 *
 *   reportName        → case-insensitive partial match (LIKE '%value%')
 *   wealthfyReportId  → exact match
 *
 * Both nullable — if both are null, all records are returned.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReportsMasterFilterRequestDto {

    private String reportName;
    private Long   wealthfyReportId;
}
