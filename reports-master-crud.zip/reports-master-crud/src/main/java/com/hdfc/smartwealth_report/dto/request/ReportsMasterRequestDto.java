package com.hdfc.smartwealth_report.dto.request;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Request DTO for creating / updating a ReportsMaster record.
 *
 * Master table rules:
 *   - wealthfyReportId  → mandatory, must not be null
 *   - reportName        → mandatory, must not be null or blank
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReportsMasterRequestDto {

    private Long          wealthfyReportId;
    private String        reportName;
    private LocalDateTime createdTime;   // optional — defaults to now on create
    private LocalDateTime updatedTime;   // optional — always refreshed on update
}
