package com.hdfc.smartwealth_report.specification;

import com.hdfc.smartwealth_report.entity.ReportsMaster;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

/**
 * JPA Specification builder for ReportsMaster dynamic filtering.
 *
 * Filter rules:
 *   reportName       → case-insensitive LIKE match  (partial search)
 *   wealthfyReportId → exact equality match
 *   both null        → no WHERE clause, all records returned
 *   both provided    → AND condition
 */
public class ReportsMasterSpecification {

    private ReportsMasterSpecification() {}

    /**
     * Builds a {@link Specification<ReportsMaster>} using only the
     * non-null / non-blank filter values.
     *
     * @param reportName       optional partial name filter
     * @param wealthfyReportId optional exact ID filter
     * @return Specification with only the active predicates applied
     */
    public static Specification<ReportsMaster> withFilters(String reportName,
                                                            Long wealthfyReportId) {

        return (Root<ReportsMaster> root, CriteriaQuery<?> query, CriteriaBuilder cb) -> {

            List<Predicate> predicates = new ArrayList<>();

            // Predicate 1: reportName — skip if null or blank
            if (reportName != null && !reportName.trim().isEmpty()) {
                predicates.add(
                    cb.like(
                        cb.lower(root.get("reportName")),
                        "%" + reportName.trim().toLowerCase() + "%"
                    )
                );
            }

            // Predicate 2: wealthfyReportId — skip if null
            if (wealthfyReportId != null) {
                predicates.add(
                    cb.equal(root.get("wealthfyReportId"), wealthfyReportId)
                );
            }

            // AND all active predicates
            // Empty list → no WHERE clause → all records returned
            return cb.and(predicates.toArray(new Predicate[0]));
        };
    }
}
