package com.hdfc.smartwealth_report.repository;

import com.hdfc.smartwealth_report.entity.ReportsMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ReportsMasterRepository extends JpaRepository<ReportsMaster, Long>,
                                                  JpaSpecificationExecutor<ReportsMaster> {

    // ── Duplicate checks used by create / update ──────────────────────────────

    /** Checks if a report with the same name already exists. */
    Optional<ReportsMaster> findByReportName(String reportName);

    /** Checks if a report with the same wealthfy ID already exists. */
    boolean existsByWealthfyReportId(Long wealthfyReportId);

    /** Lookup by external Wealthfy report ID. */
    Optional<ReportsMaster> findByWealthfyReportId(Long wealthfyReportId);
}
