package com.wce.service.impl;

import com.wce.dto.request.segmentRequest.SegmentFilterRequestDto;
import com.wce.dto.response.SegmentResponseDto;
import com.wce.mapper.SegmentMapper;
import com.wce.repository.SegmentRepository;
import com.wce.specification.SegmentSpecification;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.wce.entity.Segment;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Shows only the updated fetchAllSegments() method.
 * Drop this into SegmentServiceImpl replacing the old method.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class SegmentFetchServiceImpl {

    private final SegmentRepository segmentRepository;
    private final SegmentMapper     segmentMapper;

    /**
     * Fetches segments with optional filters.
     *
     * Filter behaviour:
     *   segmentName only       → LIKE '%value%' (case-insensitive)
     *   wealthfySegmentId only → exact match
     *   both provided          → AND condition
     *   neither provided       → returns all segments (no WHERE clause)
     *
     * Results are always sorted A→Z by segmentName.
     *
     * @param filterDto contains optional segmentName and wealthfySegmentId filters
     * @return filtered (or full) list of segments as response DTOs
     */
    @Transactional(readOnly = true)
    public List<SegmentResponseDto> fetchAllSegments(SegmentFilterRequestDto filterDto) {
        log.info("Fetching segments | segmentName={} wealthfySegmentId={}",
                filterDto.getSegmentName(), filterDto.getWealthfySegmentId());

        // Build Specification from the filter DTO
        // Internally constructs Predicates only for non-null / non-blank fields
        Specification<Segment> spec = SegmentSpecification.withFilters(
                filterDto.getSegmentName(),
                filterDto.getWealthfySegmentId()
        );

        // Always sort A→Z by segmentName (equivalent to the old findAllByOrderBySegmentNameAsc)
        Sort sort = Sort.by(Sort.Direction.ASC, "segmentName");

        List<Segment> segments = segmentRepository.findAll(spec, sort);

        log.info("Segments found: {}", segments.size());

        return segments.stream()
                .map(segmentMapper::toResponseDto)
                .collect(Collectors.toList());
    }
}
