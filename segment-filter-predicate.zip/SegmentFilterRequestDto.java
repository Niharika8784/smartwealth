package com.wce.dto.request.segmentRequest;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Optional filter DTO for fetching segments.
 * Both fields are nullable — if null, that filter is skipped.
 * If both are null, all segments are returned.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class SegmentFilterRequestDto {

    /** Filter by segment name (case-insensitive partial match). */
    private String  segmentName;

    /** Filter by exact wealthfy segment ID. */
    private Integer wealthfySegmentId;
}
