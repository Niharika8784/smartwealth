package com.wce.repository;

import com.wce.entity.Segment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface SegmentRepository extends JpaRepository<Segment, Long>,
                                           JpaSpecificationExecutor<Segment> {

    // ── Used by create / update duplicate checks ──────────────────────────────
    Optional<Segment> findBySegmentName(String segmentName);

    boolean existsByWealthfySegmentId(Integer wealthfySegmentId);

    Optional<Segment> findByWealthfySegmentId(Integer wealthfySegmentId);

    // NOTE: findAllByOrderBySegmentNameAsc() replaced by
    //       findAll(Specification, Sort) in the service.
}
