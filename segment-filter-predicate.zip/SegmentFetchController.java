package com.wce.controller;

/**
 * Updated fetchAllSegments() endpoint.
 * Drop this method into SegmentController replacing the old @GetMapping method.
 *
 * Both query params are optional:
 *   GET /api/v1/segments                                  → all segments
 *   GET /api/v1/segments?segmentName=psu                  → filtered by name
 *   GET /api/v1/segments?wealthfySegmentId=101            → filtered by ID
 *   GET /api/v1/segments?segmentName=psu&wealthfySegmentId=101  → both filters (AND)
 */

import com.wce.dto.Response;
import com.wce.dto.request.segmentRequest.SegmentFilterRequestDto;
import com.wce.dto.response.SegmentResponseDto;
import com.wce.service.SegmentService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1/segments")
@RequiredArgsConstructor
@Slf4j
public class SegmentFetchController {

    private final SegmentService segmentService;

    /**
     * GET /api/v1/segments
     * GET /api/v1/segments?segmentName=psu
     * GET /api/v1/segments?wealthfySegmentId=101
     * GET /api/v1/segments?segmentName=psu&wealthfySegmentId=101
     */
    @GetMapping
    public ResponseEntity<Response<List<SegmentResponseDto>>> fetchAllSegments(
            @RequestParam(required = false) String  segmentName,
            @RequestParam(required = false) Integer wealthfySegmentId) {

        log.info("GET all segments | segmentName={} wealthfySegmentId={}",
                segmentName, wealthfySegmentId);

        // Build filter DTO from query params (nulls when not supplied)
        SegmentFilterRequestDto filterDto = new SegmentFilterRequestDto(segmentName, wealthfySegmentId);

        List<SegmentResponseDto> segmentResponseDtos = segmentService.fetchAllSegments(filterDto);

        if (segmentResponseDtos.isEmpty()) {
            return ResponseEntity.ok(new Response<>("No segment found", null));
        }

        return ResponseEntity.ok(
                new Response<>("Fetched all segments successfully.", segmentResponseDtos));
    }
}
