package com.wce.specification;

import com.wce.entity.Segment;
import org.springframework.data.jpa.domain.Specification;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.ArrayList;
import java.util.List;

/**
 * JPA Specification builder for Segment dynamic filtering.
 *
 * Rules:
 *   - segmentName      → case-insensitive LIKE match (partial search, e.g. "psu" matches "PSU SEGMENT")
 *   - wealthfySegmentId → exact equality match
 *   - If both are null  → no WHERE clause, all records returned
 *   - If both provided  → AND condition applied between them
 */
public class SegmentSpecification {

    private SegmentSpecification() {}

    /**
     * Builds a {@link Specification<Segment>} using only the non-null, non-blank
     * filter values from the caller.
     *
     * Usage:
     *   Specification<Segment> spec = SegmentSpecification.withFilters(segmentName, wealthfySegmentId);
     *   segmentRepository.findAll(spec, sort);
     *
     * @param segmentName       optional name filter (partial, case-insensitive)
     * @param wealthfySegmentId optional exact ID filter
     * @return a Specification that applies only the non-null filters
     */
    public static Specification<Segment> withFilters(String segmentName, Integer wealthfySegmentId) {

        return (Root<Segment> root, CriteriaQuery<?> query, CriteriaBuilder cb) -> {

            List<Predicate> predicates = new ArrayList<>();

            // Filter 1: segmentName — skip if null or blank
            if (segmentName != null && !segmentName.trim().isEmpty()) {
                predicates.add(
                    cb.like(
                        cb.lower(root.get("segmentName")),       // column: lower(segment_name)
                        "%" + segmentName.trim().toLowerCase() + "%" // pattern: %psu%
                    )
                );
            }

            // Filter 2: wealthfySegmentId — skip if null
            if (wealthfySegmentId != null) {
                predicates.add(
                    cb.equal(root.get("wealthfySegmentId"), wealthfySegmentId)
                );
            }

            // AND all active predicates together
            // If predicates is empty → no WHERE clause → returns all records
            return cb.and(predicates.toArray(new Predicate[0]));
        };
    }
}
