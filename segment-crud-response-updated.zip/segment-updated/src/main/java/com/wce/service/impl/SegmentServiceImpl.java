package com.wce.service.impl;

import com.wce.dto.request.segmentRequest.SegmentRequestDto;
import com.wce.dto.response.SegmentResponseDto;
import com.wce.entity.Segment;
import com.wce.exception.ResourceNotFoundException;
import com.wce.mapper.SegmentMapper;
import com.wce.repository.SegmentRepository;
import com.wce.service.SegmentService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class SegmentServiceImpl implements SegmentService {

    private final SegmentRepository segmentRepository;
    private final SegmentMapper     segmentMapper;

    // ── CREATE ────────────────────────────────────────────────────────────────

    @Override
    @Transactional
    public SegmentResponseDto create(SegmentRequestDto requestDto) {
        log.info("Creating segment | segmentName={} wealthfySegmentId={}",
                requestDto.getSegmentName(), requestDto.getWealthfySegmentId());

        if (segmentRepository.findBySegmentName(requestDto.getSegmentName()).isPresent()) {
            throw new IllegalArgumentException(
                    "Segment with name '" + requestDto.getSegmentName() + "' already exists.");
        }

        if (requestDto.getWealthfySegmentId() != null &&
                segmentRepository.existsByWealthfySegmentId(requestDto.getWealthfySegmentId())) {
            throw new IllegalArgumentException(
                    "Segment with wealthfySegmentId '" + requestDto.getWealthfySegmentId() + "' already exists.");
        }

        Segment saved = segmentRepository.save(segmentMapper.toEntity(requestDto));
        log.info("Segment created | id={}", saved.getId());
        return segmentMapper.toResponseDto(saved);
    }

    // ── FETCH ALL ─────────────────────────────────────────────────────────────

    @Override
    @Transactional(readOnly = true)
    public List<SegmentResponseDto> fetchAllSegments() {
        log.info("Fetching all segments");
        return segmentRepository.findAllByOrderBySegmentNameAsc()
                .stream()
                .map(segmentMapper::toResponseDto)
                .collect(Collectors.toList());
    }

    // ── FETCH BY ID ───────────────────────────────────────────────────────────

    @Override
    @Transactional(readOnly = true)
    public SegmentResponseDto fetchById(Long id) {
        log.info("Fetching segment | id={}", id);
        return segmentMapper.toResponseDto(fetchOrThrow(id));
    }

    // ── FETCH BY WEALTHFY SEGMENT ID ──────────────────────────────────────────

    @Override
    @Transactional(readOnly = true)
    public SegmentResponseDto fetchByWealthfySegmentId(Integer wealthfySegmentId) {
        log.info("Fetching segment | wealthfySegmentId={}", wealthfySegmentId);
        Segment entity = segmentRepository.findByWealthfySegmentId(wealthfySegmentId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Segment not found with wealthfySegmentId: " + wealthfySegmentId));
        return segmentMapper.toResponseDto(entity);
    }

    // ── UPDATE ────────────────────────────────────────────────────────────────

    @Override
    @Transactional
    public SegmentResponseDto update(Long id, SegmentRequestDto requestDto) {
        log.info("Updating segment | id={}", id);

        Segment entity = fetchOrThrow(id);

        // Duplicate name check — exclude self
        segmentRepository.findBySegmentName(requestDto.getSegmentName())
                .ifPresent(existing -> {
                    if (!existing.getId().equals(id)) {
                        throw new IllegalArgumentException(
                                "Another segment with name '"
                                + requestDto.getSegmentName() + "' already exists.");
                    }
                });

        segmentMapper.updateEntity(entity, requestDto);
        Segment saved = segmentRepository.save(entity);
        log.info("Segment updated | id={}", saved.getId());
        return segmentMapper.toResponseDto(saved);
    }

    // ── DELETE ────────────────────────────────────────────────────────────────

    @Override
    @Transactional
    public void delete(Long id) {
        log.info("Deleting segment | id={}", id);
        fetchOrThrow(id);
        segmentRepository.deleteById(id);
        log.info("Segment deleted | id={}", id);
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    private Segment fetchOrThrow(Long id) {
        return segmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Segment", id));
    }
}
