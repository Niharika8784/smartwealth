package com.wce.service;

import com.wce.dto.request.segmentRequest.SegmentRequestDto;
import com.wce.dto.response.SegmentResponseDto;

import java.util.List;

public interface SegmentService {

    SegmentResponseDto      create(SegmentRequestDto requestDto);
    List<SegmentResponseDto> fetchAllSegments();
    SegmentResponseDto      fetchById(Long id);
    SegmentResponseDto      fetchByWealthfySegmentId(Integer wealthfySegmentId);
    SegmentResponseDto      update(Long id, SegmentRequestDto requestDto);
    void                    delete(Long id);
}
