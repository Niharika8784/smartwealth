package com.wce.controller;

import com.wce.dto.Response;
import com.wce.dto.request.segmentRequest.SegmentRequestDto;
import com.wce.dto.response.SegmentResponseDto;
import com.wce.service.SegmentService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST controller for Segment CRUD.
 *
 * Response pattern matches the organisation standard seen in EmailTemplateController:
 *   ResponseEntity<Response<T>>
 *   new Response<>("message", payload)
 *   new Response<>("No X found", null)   ← when result is empty
 *
 * Base path: /api/v1/segments
 */
@RestController
@RequestMapping("/api/v1/segments")
@RequiredArgsConstructor
@Slf4j
public class SegmentController {

    private final SegmentService segmentService;

    // ── CREATE ────────────────────────────────────────────────────────────────

    /**
     * POST /api/v1/segments
     *
     * Creates a new segment.
     *
     * Request body:
     * {
     *   "wealthfySegmentId": 101,
     *   "segmentName":       "PSU"
     * }
     */
    @PostMapping
    public ResponseEntity<Response<SegmentResponseDto>> createSegment(
            @RequestBody SegmentRequestDto requestDto) {

        log.info("POST /api/v1/segments | segmentName={}", requestDto.getSegmentName());

        SegmentResponseDto segmentResponseDto = segmentService.create(requestDto);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(new Response<>("Segment created successfully.", segmentResponseDto));
    }

    // ── FETCH ALL ─────────────────────────────────────────────────────────────

    /**
     * GET /api/v1/segments
     *
     * Retrieves all segments ordered alphabetically.
     * Returns "No segment found" with null payload when the table is empty.
     */
    @GetMapping
    public ResponseEntity<Response<List<SegmentResponseDto>>> fetchAllSegments() {

        log.info("GET all segments.");

        List<SegmentResponseDto> segmentResponseDtos = segmentService.fetchAllSegments();

        if (segmentResponseDtos.isEmpty()) {
            return ResponseEntity.ok(new Response<>("No segment found", null));
        }

        return ResponseEntity
                .ok(new Response<>("Fetched all segments successfully.", segmentResponseDtos));
    }

    // ── FETCH BY ID ───────────────────────────────────────────────────────────

    /**
     * GET /api/v1/segments/{id}
     *
     * Retrieves a segment by its primary key.
     */
    @GetMapping("/{id}")
    public ResponseEntity<Response<SegmentResponseDto>> fetchSegmentById(
            @PathVariable Long id) {

        log.info("GET segment by id={}.", id);

        SegmentResponseDto segmentResponseDto = segmentService.fetchById(id);

        return ResponseEntity
                .ok(new Response<>("Fetched segment successfully.", segmentResponseDto));
    }

    // ── FETCH BY WEALTHFY SEGMENT ID ──────────────────────────────────────────

    /**
     * GET /api/v1/segments/wealthfy/{wealthfySegmentId}
     *
     * Retrieves a segment by the external Wealthfy platform ID.
     */
    @GetMapping("/wealthfy/{wealthfySegmentId}")
    public ResponseEntity<Response<SegmentResponseDto>> fetchSegmentByWealthfyId(
            @PathVariable Integer wealthfySegmentId) {

        log.info("GET segment by wealthfySegmentId={}.", wealthfySegmentId);

        SegmentResponseDto segmentResponseDto = segmentService.fetchByWealthfySegmentId(wealthfySegmentId);

        return ResponseEntity
                .ok(new Response<>("Fetched segment successfully.", segmentResponseDto));
    }

    // ── UPDATE ────────────────────────────────────────────────────────────────

    /**
     * PUT /api/v1/segments/{id}
     *
     * Fully updates an existing segment.
     * createdTime is preserved; updatedTime is refreshed automatically.
     */
    @PutMapping("/{id}")
    public ResponseEntity<Response<SegmentResponseDto>> updateSegment(
            @PathVariable Long id,
            @RequestBody SegmentRequestDto requestDto) {

        log.info("PUT segment id={}.", id);

        SegmentResponseDto segmentResponseDto = segmentService.update(id, requestDto);

        return ResponseEntity
                .ok(new Response<>("Segment updated successfully.", segmentResponseDto));
    }

    // ── DELETE ────────────────────────────────────────────────────────────────

    /**
     * DELETE /api/v1/segments/{id}
     *
     * Permanently deletes a segment by ID.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Response<Void>> deleteSegment(@PathVariable Long id) {

        log.info("DELETE segment id={}.", id);

        segmentService.delete(id);

        return ResponseEntity
                .ok(new Response<>("Segment deleted successfully.", null));
    }
}
