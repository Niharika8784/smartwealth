package com.wce.mapper;

import com.wce.dto.request.segmentRequest.SegmentRequestDto;
import com.wce.dto.response.SegmentResponseDto;
import com.wce.entity.Segment;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Component
public class SegmentMapper {

    // ── Request DTO → new Entity ──────────────────────────────────────────────

    public Segment toEntity(SegmentRequestDto dto) {
        LocalDateTime now = LocalDateTime.now();
        return Segment.builder()
                .wealthfySegmentId(dto.getWealthfySegmentId())
                .segmentName(dto.getSegmentName())
                .createdTime(dto.getCreatedTime() != null ? dto.getCreatedTime() : now)
                .updatedTime(dto.getUpdatedTime() != null ? dto.getUpdatedTime() : now)
                .build();
    }

    // ── Request DTO → update existing Entity ──────────────────────────────────

    public void updateEntity(Segment entity, SegmentRequestDto dto) {
        entity.setWealthfySegmentId(dto.getWealthfySegmentId());
        entity.setSegmentName(dto.getSegmentName());
        entity.setUpdatedTime(LocalDateTime.now()); // createdTime is never overwritten
    }

    // ── Entity → Response DTO ─────────────────────────────────────────────────

    public SegmentResponseDto toResponseDto(Segment entity) {
        return SegmentResponseDto.builder()
                .id(entity.getId())
                .wealthfySegmentId(entity.getWealthfySegmentId())
                .segmentName(entity.getSegmentName())
                .createdTime(entity.getCreatedTime())
                .updatedTime(entity.getUpdatedTime())
                .build();
    }
}
