package com.wce.dto.request.segmentRequest;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SegmentRequestDto {

    private Integer       wealthfySegmentId;
    private String        segmentName;
    private LocalDateTime createdTime;
    private LocalDateTime updatedTime;
}
