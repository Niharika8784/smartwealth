package com.wce.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SegmentResponseDto {

    private Long          id;
    private Integer       wealthfySegmentId;
    private String        segmentName;
    private LocalDateTime createdTime;
    private LocalDateTime updatedTime;
}
