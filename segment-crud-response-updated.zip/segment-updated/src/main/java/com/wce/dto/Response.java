package com.wce.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * Organisation-standard response wrapper.
 *
 * Matches the pattern seen in the codebase:
 *   new Response<>("Fetched all email templates successfully", emailCommunicationTemplateDTOS)
 *   new Response<>("No template found", null)
 *
 * Used as: ResponseEntity<Response<T>>
 *
 * @param <T> the type of the payload (can be a single object, List, or null)
 */
@Data
@AllArgsConstructor
public class Response<T> {

    private String message;
    private T      payload;
}
