package com.wce.repository;

import com.wce.entity.Segment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface SegmentRepository extends JpaRepository<Segment, Long> {

    Optional<Segment> findBySegmentName(String segmentName);

    boolean existsByWealthfySegmentId(Integer wealthfySegmentId);

    Optional<Segment> findByWealthfySegmentId(Integer wealthfySegmentId);

    List<Segment> findAllByOrderBySegmentNameAsc();
}
