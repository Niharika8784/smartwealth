package com.hdfc.smartwealth_report.entity;

//import jakarta.persistence.*;
import javax.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

/**
 * Entity for tracking audit events related to email dispatch operations.
 * Maps to the 'reports_master' table.
 */
@Entity
@Table(name = "reports_master")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReportsMaster {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "wealthfy_report_id")
    private Long wealthfyReportId;

    @Column(name = "report_name", length = 200)
    private String reportName;

    @Column(name = "created_time")
    private LocalDateTime createdTime;

    @Column(name = "updated_time")
    private LocalDateTime updatedTime;
}
