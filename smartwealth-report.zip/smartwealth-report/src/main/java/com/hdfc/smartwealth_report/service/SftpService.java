package com.hdfc.smartwealth_report.service;

// ===================================
public interface SftpService {
    
    void downloadFile(String path);
}
