package com.hdfc.smartwealth_report.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hdfc.smartwealth_report.common.ApiResponse;
import com.hdfc.smartwealth_report.entity.ReportsMaster;
import com.hdfc.smartwealth_report.entity.Segment;
import com.hdfc.smartwealth_report.repository.ReportsMasterRepository;
import com.hdfc.smartwealth_report.repository.SegmentRepository;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/v1/lookup")
@RequiredArgsConstructor
public class LookupController {
    

    private final SegmentRepository      segmentRepository;
    private final ReportsMasterRepository reportsMasterRepository;


    @GetMapping("/segments")
    public ResponseEntity<ApiResponse<List<Segment>>> getAllSegments() {
        List<Segment> segments = segmentRepository.findAllByOrderBySegmentNameAsc();
        return ResponseEntity.ok(ApiResponse.ok("Segments fetched successfully", segments));
    }


    @GetMapping("/reports")
    public ResponseEntity<ApiResponse<List<ReportsMaster>>> getAllReports() {
        List<ReportsMaster> reports = reportsMasterRepository.findAllByOrderByReportNameAsc();
        return ResponseEntity.ok(ApiResponse.ok("Reports fetched successfully", reports));
    }
}
