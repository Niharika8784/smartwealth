package com.hdfc.smartwealth_report.serviceImpl;

import org.springframework.stereotype.Service;

import com.hdfc.smartwealth_report.service.SftpService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class SftpServiceImpl implements SftpService{

    @Override
    public void downloadFile(String path) {

        // connect to SFTP
        // download file
        // close connection
    }
    
}
