package com.hdfc.smartwealth_report.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class ApiResponseDto {
    
    private boolean success;
    private String message;
    private String requestId;
}
