package com.hdfc.smartwealth_report.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hdfc.smartwealth_report.dto.request.AdhocEmailRequestDto;
import com.hdfc.smartwealth_report.dto.response.ApiResponseDto;
import com.hdfc.smartwealth_report.service.EmailService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
//********************************* */
@Slf4j
@RestController
@RequestMapping("/sw-reporting/report-generation")
@RequiredArgsConstructor
public class AdhocReportController {
    
    private final EmailService emailService;

    @PostMapping("/email-client")
    public ResponseEntity<ApiResponseDto> sendEmail(
            @RequestBody AdhocEmailRequestDto request) {

        log.info("Received ADHOC email request for requestId={}",
                request.getRequestId());

        emailService.sendEmail(request);

        return ResponseEntity.ok(
                ApiResponseDto.builder()
                        .success(true)
                        .message("Email sent successfully")
                        .requestId(request.getRequestId())
                        .build()
        );
    }
}
