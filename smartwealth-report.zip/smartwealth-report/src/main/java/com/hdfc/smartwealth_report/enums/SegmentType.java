package com.hdfc.smartwealth_report.enums;

public enum SegmentType {
    
    PSU,
    RETAIL,
    CORPORATE
}
