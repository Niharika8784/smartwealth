package com.hdfc.smartwealth_report.exceptionHandler;

// ===================================
public class EmailSendingException extends RuntimeException {
    
    public EmailSendingException(String message) {
        super(message);
    }
}
