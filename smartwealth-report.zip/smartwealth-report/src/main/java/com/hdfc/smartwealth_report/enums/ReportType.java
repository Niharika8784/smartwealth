package com.hdfc.smartwealth_report.enums;

public enum ReportType {
    
    CLIENT,
    FAMILY
}
