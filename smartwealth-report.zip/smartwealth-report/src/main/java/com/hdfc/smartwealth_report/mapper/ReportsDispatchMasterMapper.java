package com.hdfc.smartwealth_report.mapper;

import com.hdfc.smartwealth_report.dto.ReportsDispatchMasterRequestDto;
import com.hdfc.smartwealth_report.dto.ReportsDispatchMasterResponseDto;
import com.hdfc.smartwealth_report.entity.ReportsDispatchMaster;
import com.hdfc.smartwealth_report.entity.ReportsMaster;
import com.hdfc.smartwealth_report.entity.Segment;
import com.hdfc.smartwealth_report.enums.DispatchStatus;

public class ReportsDispatchMasterMapper {
    
    private ReportsDispatchMasterMapper() {}

    // ── Request DTO → new Entity ───

    public static ReportsDispatchMaster toEntity(ReportsDispatchMasterRequestDto dto,
                                                  Segment segment,
                                                  ReportsMaster report) {
        return ReportsDispatchMaster.builder()
                .segmentId(dto.getSegmentId())
                .customUserFilePath(dto.getCustomUserFilePath())
                .report(report)
                .reportType(dto.getReportType())
                .status(dto.getStatus() != null ? dto.getStatus() : DispatchStatus.DRAFT)
                .effectiveDate(dto.getEffectiveDate())
                .dispatchDate(dto.getDispatchDate())
                .reportFormat(dto.getReportFormat())
                .dateFormatType(dto.getDateFormatType())
                .reportFromDate(dto.getReportFromDate())
                .reportToDate(dto.getReportToDate())
                .frequency(dto.getFrequency())
                .build();
    }

    // ── Request DTO → update existing Entity ──

    public static void updateEntity(ReportsDispatchMaster entity,
                                    ReportsDispatchMasterRequestDto dto,
                                    ReportsMaster report) {
        entity.setSegmentId(dto.getSegmentId());
        entity.setCustomUserFilePath(dto.getCustomUserFilePath());
        entity.setReport(report);
        entity.setReportType(dto.getReportType());
        entity.setEffectiveDate(dto.getEffectiveDate());
        entity.setDispatchDate(dto.getDispatchDate());
        entity.setReportFormat(dto.getReportFormat());
        entity.setDateFormatType(dto.getDateFormatType());
        entity.setReportFromDate(dto.getReportFromDate());
        entity.setReportToDate(dto.getReportToDate());
        entity.setFrequency(dto.getFrequency());
        if (dto.getStatus() != null) {
            entity.setStatus(dto.getStatus());
        }
    }

    // ── Entity → Response DTO ───

    public static ReportsDispatchMasterResponseDto toResponseDto(ReportsDispatchMaster entity,
                                                                  Segment segment) {
        return ReportsDispatchMasterResponseDto.builder()
                .id(entity.getId())
                .segmentId(entity.getSegmentId())
                .segmentName(segment != null ? segment.getSegmentName() : null)
                .reportId(entity.getReport() != null ? entity.getReport().getId() : null)
                .reportName(entity.getReport() != null ? entity.getReport().getReportName() : null)
                .reportType(entity.getReportType())
                .frequency(entity.getFrequency())
                .frequencyLabel(resolveFrequencyLabel(entity.getFrequency()))
                .effectiveDate(entity.getEffectiveDate())
                .dispatchDate(entity.getDispatchDate())
                .reportFormat(entity.getReportFormat())
                .dateFormatType(entity.getDateFormatType())
                .reportFromDate(entity.getReportFromDate())
                .reportToDate(entity.getReportToDate())
                .customUserFilePath(entity.getCustomUserFilePath())
                .status(entity.getStatus())
                .authorizationLabel(resolveAuthorizationLabel(entity.getStatus()))
                .createdTime(entity.getCreatedTime())
                .updatedTime(entity.getUpdatedTime())
                .build();
    }

    // ── Helpers ──

    public static String resolveFrequencyLabel(Integer frequency) {
        if (frequency == null) return null;
        if (frequency == 1)  return "Monthly";
        if (frequency == 3)  return "Quarterly";
        if (frequency == 6)  return "Half-Yearly";
        if (frequency == 12) return "Yearly";
        if (frequency == 0)  return "On-Demand";
        return String.valueOf(frequency);
    }

    public static String resolveAuthorizationLabel(DispatchStatus status) {
        if (status == null) return null;
        if (status == DispatchStatus.APPROVAL_PENDING) return "Pending for Authorization";
        if (status == DispatchStatus.APPROVED)         return "Authorized";
        if (status == DispatchStatus.ACTIVE)           return "Authorized";
        if (status == DispatchStatus.INACTIVE)         return "Authorized";
        if (status == DispatchStatus.REJECTED)         return "Rejected";
        if (status == DispatchStatus.STOPPED)          return "Stopped";
        if (status == DispatchStatus.DRAFT)            return "Draft";
        return status.name();
    }

}
