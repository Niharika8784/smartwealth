package com.hdfc.smartwealth_report.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hdfc.smartwealth_report.entity.ReportsMaster;

@Repository
public interface ReportsMasterRepository extends JpaRepository<ReportsMaster, Long>{
    
    List<ReportsMaster> findAllByOrderByReportNameAsc();
}
