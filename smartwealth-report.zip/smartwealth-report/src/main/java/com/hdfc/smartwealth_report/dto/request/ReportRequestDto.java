package com.hdfc.smartwealth_report.dto.request;

import com.hdfc.smartwealth_report.enums.ReportType;
import com.hdfc.smartwealth_report.enums.SegmentType;

import lombok.Data;

@Data
public class ReportRequestDto {

    private SegmentType segmentType;
    private ReportType reportType;
    private String reportName;
    private String reportFormat;
    private String reportDateType;
    private String fromDate;
    private String toDate;
    
}
