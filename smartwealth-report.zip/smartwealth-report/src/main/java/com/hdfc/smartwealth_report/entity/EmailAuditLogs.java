package com.hdfc.smartwealth_report.entity;


import lombok.*;
import java.time.LocalDateTime;

import javax.persistence.*;

/**
 * Entity for tracking audit events related to email dispatch operations.
 * Maps to the 'email_audit_logs' table.
 */
@Entity
@Table(name = "email_audit_logs")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EmailAuditLogs {
    
     @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "scheduler_job_id")
    private Long schedulerJobId;

    @Column(name = "segment_id")
    private Long segmentId;

    @Column(name = "report_id")
    private Long reportId;

    @Column(name = "recipient_email", length = 300)
    private String recipientEmail;

    @Column(name = "customer_id")
    private Long customerId;

    @Column(name = "account_id")
    private Long accountId;

    /**
     * Status of the individual email send attempt (e.g. SENT, FAILED, BOUNCED).
     */
    @Column(name = "status", length = 50)
    private String status;

    @Column(name = "failure_reason", columnDefinition = "TEXT")
    private String failureReason;

    @Column(name = "sent_time")
    private LocalDateTime sentTime;

    @Column(name = "created_time")
    private LocalDateTime createdTime;

    @Column(name = "updated_time")
    private LocalDateTime updatedTime;
}
