package com.hdfc.smartwealth_report.dto.response;

import lombok.Data;

@Data
public class ReportResponseDto {
    
    private Payload payload;
    private String message;

    @Data
    public static class Payload {
        private String requestId;
    }
}
