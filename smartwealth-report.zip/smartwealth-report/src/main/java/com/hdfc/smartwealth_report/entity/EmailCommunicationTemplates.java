package com.hdfc.smartwealth_report.entity;


//import jakarta.persistence.*;
import javax.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

/**
 * Entity for tracking audit events related to email dispatch operations.
 * Maps to the 'email_communication_templates' table.
 */
@Entity
@Table(name = "email_communication_templates")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EmailCommunicationTemplates {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "template_name", length = 200)
    private String templateName;

    @Column(name = "subject", length = 500)
    private String subject;

    @Column(name = "body", columnDefinition = "TEXT")
    private String body;

    @Column(name = "report_type", length = 20)
    private String reportType;

    @Column(name = "is_active")
    private Boolean isActive;

    @Column(name = "created_time")
    private LocalDateTime createdTime;

    @Column(name = "updated_time")
    private LocalDateTime updatedTime;
    
}
