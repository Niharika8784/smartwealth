package com.hdfc.smartwealth_report.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hdfc.smartwealth_report.dto.request.CallbackRequestDto;
import com.hdfc.smartwealth_report.dto.response.ApiResponseDto;
import com.hdfc.smartwealth_report.service.ReportService;

import lombok.RequiredArgsConstructor;
// ************************************
@RestController
@RequestMapping("/sw-reporting")
@RequiredArgsConstructor
public class CallbackController {

    private final ReportService reportService;

    @PostMapping("/wbce/customer-reports")
    public ResponseEntity<ApiResponseDto> callback(
            @RequestBody CallbackRequestDto request) {

        reportService.processCallback(request);

        return ResponseEntity.ok(
                new ApiResponseDto(
                        true,
                        "Callback processed successfully",
                        request.getRequestId()
                )
        );
    }
    
}
