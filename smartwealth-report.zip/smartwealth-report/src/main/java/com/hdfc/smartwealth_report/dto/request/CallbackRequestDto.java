package com.hdfc.smartwealth_report.dto.request;

import lombok.Data;

@Data
public class CallbackRequestDto {
    
    private String requestId;
    private String status;
    private String sftpFolderPath;
}
