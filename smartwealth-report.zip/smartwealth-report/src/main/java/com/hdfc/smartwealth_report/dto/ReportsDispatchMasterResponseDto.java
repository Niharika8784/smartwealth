package com.hdfc.smartwealth_report.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.hdfc.smartwealth_report.enums.DispatchStatus;
import com.hdfc.smartwealth_report.enums.ReportType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * DTO returned for every read operation on a dispatch master record.
 * Supplies all columns shown in the listing table:
 *   Segment | Report Type | Report Frequency | Daily Email Limit | Effective Date | Status | Authorization
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReportsDispatchMasterResponseDto {
    
    private Long id;

    // ── Segment ──────────────────────────────────────────────────────────────
    private Long segmentId;
    private String segmentName;             // resolved from segments table

    // ── Report ───────────────────────────────────────────────────────────────
    private Long reportId;
    private String reportName;              // resolved from reports_master

    private ReportType reportType;          // CLIENT | FAMILY

    // ── Dispatch configuration ────────────────────────────────────────────────
    private Integer frequency;              // raw int
    private String  frequencyLabel;         // Monthly / Quarterly / Half-Yearly / Yearly / On-Demand
    private LocalDate effectiveDate;
    private Integer dispatchDate;
    private String  reportFormat;           // PDF | EXCEL | PDF,EXCEL
    private String  dateFormatType;         // AS_ON_DATE | DATE_RANGE
    private LocalDateTime reportFromDate;
    private LocalDateTime reportToDate;
    private String  customUserFilePath;

    // ── Status & Authorization ────────────────────────────────────────────────
    private DispatchStatus status;

    /**
     * Authorization label shown in the last column.
     * Derived from status: APPROVAL_PENDING → "Pending for Authorization",
     * APPROVED → "Authorized", etc.
     */
    private String authorizationLabel;

    // ── Audit ─────────────────────────────────────────────────────────────────
    private LocalDateTime createdTime;
    private LocalDateTime updatedTime;
}
