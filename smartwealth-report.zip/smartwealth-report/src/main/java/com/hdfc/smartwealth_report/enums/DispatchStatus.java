package com.hdfc.smartwealth_report.enums;

public enum DispatchStatus {
    
    DRAFT,
    ACTIVE,
    INACTIVE,
    APPROVAL_PENDING,
    APPROVED,
    STOPPED,
    REJECTED
}
