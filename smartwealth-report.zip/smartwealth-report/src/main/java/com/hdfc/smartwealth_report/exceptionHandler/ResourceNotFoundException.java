package com.hdfc.smartwealth_report.exceptionHandler;

public class ResourceNotFoundException extends RuntimeException  {
    
    public ResourceNotFoundException(String message) {
        super(message);
    }

    public ResourceNotFoundException(String entity, Long id) {
        super(entity + " not found with id: " + id);
    }
}
