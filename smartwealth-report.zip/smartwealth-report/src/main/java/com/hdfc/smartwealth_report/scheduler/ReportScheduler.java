package com.hdfc.smartwealth_report.scheduler;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.hdfc.smartwealth_report.service.ReportService;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class ReportScheduler {
    
    private final ReportService reportService;

    @Scheduled(cron = "0 0 9 * * ?")
    public void generateReports() {

        reportService.initiateReportGeneration();
    }
}

