package com.hdfc.smartwealth_report.serviceImpl;

import org.springframework.stereotype.Service;

import com.hdfc.smartwealth_report.client.WealthifyClient;
import com.hdfc.smartwealth_report.dto.request.CallbackRequestDto;
import com.hdfc.smartwealth_report.dto.request.ReportRequestDto;
import com.hdfc.smartwealth_report.dto.response.ReportResponseDto;
import com.hdfc.smartwealth_report.entity.ReportRequest;
import com.hdfc.smartwealth_report.enums.ReportStatus;
import com.hdfc.smartwealth_report.enums.ReportType;
import com.hdfc.smartwealth_report.enums.SegmentType;
import com.hdfc.smartwealth_report.repository.ReportRequestRepository;
import com.hdfc.smartwealth_report.service.EmailService;
import com.hdfc.smartwealth_report.service.ReportService;
import com.hdfc.smartwealth_report.service.SftpService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@RequiredArgsConstructor
@Slf4j
public class ReportServiceImpl implements ReportService {

    private final WealthifyClient wealthifyClient;
    private final ReportRequestRepository repository;
    private final EmailService emailService;
    private final SftpService sftpService;

    @Override
    public void initiateReportGeneration() {

        ReportRequestDto request = new ReportRequestDto();
        request.setSegmentType(SegmentType.PSU);
        request.setReportType(ReportType.CLIENT);
        ReportResponseDto response = wealthifyClient.generateReport(request);
        ReportRequest entity = new ReportRequest();
        entity.setRequestId(response.getPayload().getRequestId());
        entity.setStatus(ReportStatus.PROCESSING);
        repository.save(entity);
        log.info("Report initiated");
    }

    @Override
    public void processCallback(CallbackRequestDto request) {
        log.info("Callback received");


        // Download report
        sftpService.downloadFile(request.getSftpFolderPath());

        // Send email
        emailService.sendEmail();

        // Update DB
    }

}
