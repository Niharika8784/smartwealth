package com.hdfc.smartwealth_report.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hdfc.smartwealth_report.entity.ReportRequest;

public interface ReportRequestRepository extends JpaRepository<ReportRequest, Long> {

    
}


// =============================================