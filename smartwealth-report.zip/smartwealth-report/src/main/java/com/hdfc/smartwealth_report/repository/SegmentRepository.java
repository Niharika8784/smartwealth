package com.hdfc.smartwealth_report.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hdfc.smartwealth_report.entity.Segment;

@Repository
public interface SegmentRepository  extends JpaRepository<Segment, Long> {
    
    Optional<Segment> findBySegmentName(String segmentName);
    List<Segment> findAllByOrderBySegmentNameAsc();
}
