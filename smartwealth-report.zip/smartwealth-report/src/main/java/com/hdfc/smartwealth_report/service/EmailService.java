package com.hdfc.smartwealth_report.service;

import com.hdfc.smartwealth_report.dto.request.AdhocEmailRequestDto;

// ===================================
public interface EmailService {
    
    void sendEmail();

    void sendEmail(AdhocEmailRequestDto request);
}
