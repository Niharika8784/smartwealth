package com.hdfc.smartwealth_report.serviceImpl;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.hdfc.smartwealth_report.dto.DispatchStatusUpdateDto;
import com.hdfc.smartwealth_report.dto.ReportsDispatchMasterRequestDto;
import com.hdfc.smartwealth_report.dto.ReportsDispatchMasterResponseDto;
import com.hdfc.smartwealth_report.entity.ReportsDispatchMaster;
import com.hdfc.smartwealth_report.entity.ReportsMaster;
import com.hdfc.smartwealth_report.entity.Segment;
import com.hdfc.smartwealth_report.enums.DispatchStatus;
import com.hdfc.smartwealth_report.enums.ReportType;
import com.hdfc.smartwealth_report.exceptionHandler.ResourceNotFoundException;
import com.hdfc.smartwealth_report.mapper.ReportsDispatchMasterMapper;
import com.hdfc.smartwealth_report.repository.ReportsDispatchMasterRepository;
import com.hdfc.smartwealth_report.repository.ReportsMasterRepository;
import com.hdfc.smartwealth_report.repository.SegmentRepository;
import com.hdfc.smartwealth_report.service.ReportsDispatchMasterService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Slf4j
public class ReportsDispatchMasterServiceImpl implements ReportsDispatchMasterService{
    
    private final ReportsDispatchMasterRepository dispatchMasterRepo;
    private final SegmentRepository               segmentRepo;
    private final ReportsMasterRepository         reportsMasterRepo;

    // ── CREATE ───

    @Override
    @Transactional
    public ReportsDispatchMasterResponseDto create(ReportsDispatchMasterRequestDto dto) {
        log.info("Creating dispatch master for segmentId={}, reportId={}", dto.getSegmentId(), dto.getReportId());

        Segment segment = segmentRepo.findById(dto.getSegmentId())
                .orElseThrow(() -> new ResourceNotFoundException("Segment", dto.getSegmentId()));

        ReportsMaster report = reportsMasterRepo.findById(dto.getReportId())
                .orElseThrow(() -> new ResourceNotFoundException("ReportsMaster", dto.getReportId()));

        
        boolean duplicate = dispatchMasterRepo.existsBySegmentIdAndReport_IdAndStatusIn(
                dto.getSegmentId(), dto.getReportId(),
                Arrays.asList(DispatchStatus.ACTIVE, DispatchStatus.APPROVAL_PENDING, DispatchStatus.APPROVED));
        if (duplicate) {
            throw new IllegalArgumentException(
                    "An active or pending dispatch configuration already exists for this segment and report.");
        }

        ReportsDispatchMaster entity = ReportsDispatchMasterMapper.toEntity(dto, segment, report);
        entity.setCreatedTime(LocalDateTime.now());
        entity.setUpdatedTime(LocalDateTime.now());

        ReportsDispatchMaster saved = dispatchMasterRepo.save(entity);
        log.info("Dispatch master created with id={}", saved.getId());

        return ReportsDispatchMasterMapper.toResponseDto(saved, segment);
    }

    // ── READ (single) ───

    @Override
    @Transactional(readOnly = true)
    public ReportsDispatchMasterResponseDto getById(Long id) {
        ReportsDispatchMaster entity = fetchOrThrow(id);
        Segment segment = resolveSegment(entity.getSegmentId());
        return ReportsDispatchMasterMapper.toResponseDto(entity, segment);
    }

    // ── READ (list with filters) ────

    @Override
    @Transactional(readOnly = true)
    public List<ReportsDispatchMasterResponseDto> getAll(ReportType reportType, DispatchStatus status) {
        List<ReportsDispatchMaster> records = dispatchMasterRepo.findByFilters(reportType, status);
        return records.stream()
                .map(e -> ReportsDispatchMasterMapper.toResponseDto(e, resolveSegment(e.getSegmentId())))
                .collect(Collectors.toList());
    }

    // ── UPDATE (full edit) ────

    @Override
    @Transactional
    public ReportsDispatchMasterResponseDto update(Long id, ReportsDispatchMasterRequestDto dto) {
        log.info("Updating dispatch master id={}", id);

        ReportsDispatchMaster entity = fetchOrThrow(id);

        if (entity.getStatus() != DispatchStatus.DRAFT &&
            entity.getStatus() != DispatchStatus.INACTIVE) {
            throw new IllegalArgumentException(
                    "Only DRAFT or INACTIVE dispatch masters can be edited. Current status: " + entity.getStatus());
        }

        Segment segment = segmentRepo.findById(dto.getSegmentId())
                .orElseThrow(() -> new ResourceNotFoundException("Segment", dto.getSegmentId()));

        ReportsMaster report = reportsMasterRepo.findById(dto.getReportId())
                .orElseThrow(() -> new ResourceNotFoundException("ReportsMaster", dto.getReportId()));

        ReportsDispatchMasterMapper.updateEntity(entity, dto, report);
        entity.setUpdatedTime(LocalDateTime.now());

        ReportsDispatchMaster saved = dispatchMasterRepo.save(entity);
        return ReportsDispatchMasterMapper.toResponseDto(saved, segment);
    }

    // ── UPDATE STATUS ───

    @Override
    @Transactional
    public ReportsDispatchMasterResponseDto updateStatus(Long id, DispatchStatusUpdateDto statusDto) {
        log.info("Updating status of dispatch master id={} to {}", id, statusDto.getStatus());

        ReportsDispatchMaster entity = fetchOrThrow(id);
        validateStatusTransition(entity.getStatus(), statusDto.getStatus());

        entity.setStatus(statusDto.getStatus());
        entity.setUpdatedTime(LocalDateTime.now());

        ReportsDispatchMaster saved = dispatchMasterRepo.save(entity);
        Segment segment = resolveSegment(saved.getSegmentId());
        return ReportsDispatchMasterMapper.toResponseDto(saved, segment);
    }

    // ── DELETE ─

    @Override
    @Transactional
    public void delete(Long id) {
        log.info("Deleting dispatch master id={}", id);
        ReportsDispatchMaster entity = fetchOrThrow(id);

        if (entity.getStatus() == DispatchStatus.DRAFT) {
            dispatchMasterRepo.deleteById(id);
        } else if (entity.getStatus() == DispatchStatus.INACTIVE ||
                   entity.getStatus() == DispatchStatus.STOPPED) {
            entity.setStatus(DispatchStatus.STOPPED);
            entity.setUpdatedTime(LocalDateTime.now());
            dispatchMasterRepo.save(entity);
        } else {
            throw new IllegalArgumentException(
                    "Cannot delete a dispatch master with status: " + entity.getStatus() +
                    ". Stop or deactivate it first.");
        }
    }

    // ── Private helpers ───

    private ReportsDispatchMaster fetchOrThrow(Long id) {
        return dispatchMasterRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("ReportsDispatchMaster", id));
    }

    private Segment resolveSegment(Long segmentId) {
        if (segmentId == null) return null;
        return segmentRepo.findById(segmentId).orElse(null);
    }

    
    private void validateStatusTransition(DispatchStatus current, DispatchStatus next) {
        boolean allowed = false;

        if (current == DispatchStatus.DRAFT) {
            allowed = (next == DispatchStatus.APPROVAL_PENDING);
        } else if (current == DispatchStatus.APPROVAL_PENDING) {
            allowed = (next == DispatchStatus.APPROVED || next == DispatchStatus.REJECTED);
        } else if (current == DispatchStatus.APPROVED) {
            allowed = (next == DispatchStatus.ACTIVE);
        } else if (current == DispatchStatus.ACTIVE) {
            allowed = (next == DispatchStatus.INACTIVE || next == DispatchStatus.STOPPED);
        } else if (current == DispatchStatus.INACTIVE) {
            allowed = (next == DispatchStatus.ACTIVE || next == DispatchStatus.STOPPED);
        } else if (current == DispatchStatus.REJECTED) {
            allowed = (next == DispatchStatus.DRAFT);
        }
        // STOPPED is terminal — allowed stays false

        if (!allowed) {
            throw new IllegalArgumentException(
                    "Invalid status transition: " + current + " -> " + next);
        }
    }

}
