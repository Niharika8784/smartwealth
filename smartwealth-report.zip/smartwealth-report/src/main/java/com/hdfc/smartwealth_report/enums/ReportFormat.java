package com.hdfc.smartwealth_report.enums;

public enum ReportFormat {
    
    PDF,
    EXCEL
}
