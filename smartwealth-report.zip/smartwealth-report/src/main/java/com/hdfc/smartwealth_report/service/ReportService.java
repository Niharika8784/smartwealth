package com.hdfc.smartwealth_report.service;

import com.hdfc.smartwealth_report.dto.request.CallbackRequestDto;

// ===================================
public interface ReportService {
    
    void initiateReportGeneration();
    void processCallback(CallbackRequestDto request);
}
