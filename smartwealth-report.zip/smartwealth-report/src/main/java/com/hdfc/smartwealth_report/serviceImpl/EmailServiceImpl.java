package com.hdfc.smartwealth_report.serviceImpl;

import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.hdfc.smartwealth_report.dto.request.AdhocEmailRequestDto;
import com.hdfc.smartwealth_report.exceptionHandler.EmailSendingException;
import com.hdfc.smartwealth_report.service.EmailService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class EmailServiceImpl implements EmailService {

    private final JavaMailSender mailSender;

    @Override
    public void sendEmail() {
        SimpleMailMessage message = new SimpleMailMessage();

        message.setTo("test@gmail.com");

        message.setSubject("Report");

        message.setText("Please find attached report");

        mailSender.send(message);
    }

    @Override
    public void sendEmail(AdhocEmailRequestDto request) {
        try {

            log.info("Sending email for requestId={}",
                    request.getRequestId());

            SimpleMailMessage message = new SimpleMailMessage();

            message.setTo(request.getEmail());

            message.setSubject("Portfolio Report");

            message.setText("Please find attached report");

            mailSender.send(message);

            log.info("Email sent successfully for requestId={}",
                    request.getRequestId());

        } catch (Exception ex) {

            log.error("Failed to send email for requestId={}",
                    request.getRequestId(), ex);

            throw new EmailSendingException(
                    "Failed to send email");
        }
    }

}
