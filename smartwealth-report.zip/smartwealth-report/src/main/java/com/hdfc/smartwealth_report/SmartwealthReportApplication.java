package com.hdfc.smartwealth_report;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class SmartwealthReportApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartwealthReportApplication.class, args);
	}

}
