package com.hdfc.smartwealth_report.dto;

import com.hdfc.smartwealth_report.enums.DispatchStatus;

import javax.validation.constraints.NotNull;

import lombok.*;

/**
 * Lightweight DTO used when only the status field needs to be changed.
 * e.g. toggling Active ↔ Inactive from the listing table.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DispatchStatusUpdateDto {
    
    @NotNull(message = "Status is required")
    private DispatchStatus status;

    /** Reason required when status = REJECTED or STOPPED. */
    private String reason;
    
}
