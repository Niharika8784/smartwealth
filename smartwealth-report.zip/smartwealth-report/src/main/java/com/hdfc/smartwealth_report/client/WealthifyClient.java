package com.hdfc.smartwealth_report.client;

import org.springframework.lang.NonNull;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.hdfc.smartwealth_report.dto.request.ReportRequestDto;
import com.hdfc.smartwealth_report.dto.response.ReportResponseDto;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class WealthifyClient {

    private final WebClient webClient;

    public ReportResponseDto generateReport(
            @NonNull ReportRequestDto request) {

        return webClient.post()
                .uri("https://wealthify-api/generate-report")
                .bodyValue(request)
                .retrieve()
                .bodyToMono(ReportResponseDto.class)
                .block();
    }
    
}
