package com.hdfc.smartwealth_report.dto.response;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EmailResponseDto {
    
    private boolean success;

    private String message;

    private String requestId;

    private String errorCode;
}
