package com.hdfc.smartwealth_report.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hdfc.smartwealth_report.common.ApiResponse;
import com.hdfc.smartwealth_report.dto.DispatchStatusUpdateDto;
import com.hdfc.smartwealth_report.dto.ReportsDispatchMasterRequestDto;
import com.hdfc.smartwealth_report.dto.ReportsDispatchMasterResponseDto;
import com.hdfc.smartwealth_report.enums.DispatchStatus;
import com.hdfc.smartwealth_report.enums.ReportType;
import com.hdfc.smartwealth_report.service.ReportsDispatchMasterService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/v1/dispatch-master")
@RequiredArgsConstructor
public class ReportsDispatchMasterController {

    private final ReportsDispatchMasterService dispatchMasterService;

    // ── CREATE ───

    @PostMapping
    public ResponseEntity<ApiResponse<ReportsDispatchMasterResponseDto>> create(
            @Valid @RequestBody ReportsDispatchMasterRequestDto requestDto) {

        ReportsDispatchMasterResponseDto response = dispatchMasterService.create(requestDto);
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Dispatch master created successfully", response));
    }

    // ── READ (listing table) ───

    @GetMapping
    public ResponseEntity<ApiResponse<List<ReportsDispatchMasterResponseDto>>> getAll(
            @RequestParam(required = false) ReportType reportType,
            @RequestParam(required = false) DispatchStatus status) {

        List<ReportsDispatchMasterResponseDto> list = dispatchMasterService.getAll(reportType, status);
        return ResponseEntity.ok(ApiResponse.ok("Dispatch masters fetched successfully", list));
    }

    // ── READ (single) ──

    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<ReportsDispatchMasterResponseDto>> getById(
            @PathVariable Long id) {

        ReportsDispatchMasterResponseDto response = dispatchMasterService.getById(id);
        return ResponseEntity.ok(ApiResponse.ok("Dispatch master fetched successfully", response));
    }

    // ── UPDATE (full edit) ───

    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<ReportsDispatchMasterResponseDto>> update(
            @PathVariable Long id,
            @Valid @RequestBody ReportsDispatchMasterRequestDto requestDto) {

        ReportsDispatchMasterResponseDto response = dispatchMasterService.update(id, requestDto);
        return ResponseEntity.ok(ApiResponse.ok("Dispatch master updated successfully", response));
    }

    // ── UPDATE STATUS (toggle / submit for approval / stop) ─────

    @PatchMapping("/{id}/status")
    public ResponseEntity<ApiResponse<ReportsDispatchMasterResponseDto>> updateStatus(
            @PathVariable Long id,
            @Valid @RequestBody DispatchStatusUpdateDto statusDto) {

        ReportsDispatchMasterResponseDto response = dispatchMasterService.updateStatus(id, statusDto);
        return ResponseEntity.ok(ApiResponse.ok("Status updated to " + statusDto.getStatus(), response));
    }

    // ── DELETE ──
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable Long id) {
        dispatchMasterService.delete(id);
        return ResponseEntity.ok(ApiResponse.ok("Dispatch master deleted successfully", null));
    }

}
