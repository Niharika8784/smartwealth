package com.hdfc.smartwealth_report.dto.request;

import lombok.Data;

@Data
public class AdhocEmailRequestDto {

    private String requestId;
    private String clientId;
    private String customerName;
    private String email;
    private String reportType;
    private String reportFormat;
    private String sftpFilePath;
}
