package com.hdfc.smartwealth_report.enums;

public enum ApprovalStatus {
    
    APPROVAL_PENDING,
    APPROVED,
    REJECTED
}
