package com.hdfc.smartwealth_report.enums;

public enum ReportDateType {
    
    RANGE_BASED,
    DAILY,
    MONTHLY
}
