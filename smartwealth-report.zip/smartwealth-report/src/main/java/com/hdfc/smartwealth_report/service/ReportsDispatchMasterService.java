package com.hdfc.smartwealth_report.service;

import java.util.List;

import com.hdfc.smartwealth_report.dto.DispatchStatusUpdateDto;
import com.hdfc.smartwealth_report.dto.ReportsDispatchMasterRequestDto;
import com.hdfc.smartwealth_report.dto.ReportsDispatchMasterResponseDto;
import com.hdfc.smartwealth_report.enums.DispatchStatus;
import com.hdfc.smartwealth_report.enums.ReportType;

public interface ReportsDispatchMasterService {
    
 
    ReportsDispatchMasterResponseDto create(ReportsDispatchMasterRequestDto requestDto);

  
    ReportsDispatchMasterResponseDto getById(Long id);

    
    List<ReportsDispatchMasterResponseDto> getAll(ReportType reportType, DispatchStatus status);


    ReportsDispatchMasterResponseDto update(Long id, ReportsDispatchMasterRequestDto requestDto);

 
    ReportsDispatchMasterResponseDto updateStatus(Long id, DispatchStatusUpdateDto statusDto);

 
    void delete(Long id);
}
