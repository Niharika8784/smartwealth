package com.hdfc.smartwealth_report.entity;

//import jakarta.persistence.*;
import javax.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

/**
 * Entity for tracking audit events related to email dispatch operations.
 * Maps to the 'wealth_blocked_accounts' table.
 */
@Entity
@Table(name = "wealth_blocked_accounts")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WealthBlockedAccounts {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "email_id", length = 300)
    private String emailId;

    @Column(name = "created_time")
    private LocalDateTime createdTime;

    @Column(name = "updated_time")
    private LocalDateTime updatedTime;
}
