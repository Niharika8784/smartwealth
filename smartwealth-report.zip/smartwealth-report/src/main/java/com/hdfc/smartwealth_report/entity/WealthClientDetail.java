package com.hdfc.smartwealth_report.entity;

import java.time.LocalDateTime;

//import jakarta.persistence.*;
import javax.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "wealth_client_details")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class WealthClientDetail {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "customer_id")
    private Long customerId;

    @Column(name = "account_id")
    private Long accountId;

    @Column(name = "user_id")
    private Long userId;

    @Column(name = "email_id", length = 300)
    private String emailId;

    @Column(name = "isa_number", length = 200)
    private String isaNumber;

    @Column(name = "account_no_offline", length = 100)
    private String accountNoOffline;

    @Column(name = "account_no_online", length = 100)
    private String accountNoOnline;

    @Column(name = "account_no_heldaway", length = 100)
    private String accountNoHeldaway;

    @Column(name = "client_name", length = 300)
    private String clientName;

    @Column(name = "risk_profile", length = 100)
    private String riskProfile;

    @Column(name = "created_time")
    private LocalDateTime createdTime;

    @Column(name = "updated_time")
    private LocalDateTime updatedTime;
    
}
