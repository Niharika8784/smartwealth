package com.hdfc.smartwealth_report.entity;

//import jakarta.persistence.*;
import javax.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

import com.hdfc.smartwealth_report.enums.ApprovalStatus;

/**
 * Entity for tracking audit events related to email dispatch operations.
 * Maps to the 'reports_dispatch_master_approval_requests' table.
 */
@Entity
@Table(name = "reports_dispatch_master_approval_requests")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReportsDispatchMasterApprovalRequests {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "scheduler_master_id", referencedColumnName = "id")
    private ReportsDispatchSchedulerJobs schedulerMaster;

    @Column(name = "description", columnDefinition = "TEXT")
    private String description;

    @Column(name = "identifier", length = 100)
    private String identifier;

    /**
     * Stores arbitrary JSON payload for the approval request.
     * Stored as JSONB in PostgreSQL for efficient querying.
     */

    @Column(name = "data", columnDefinition = "jsonb")
    private String data;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", length = 30)
    private ApprovalStatus status;

    @Column(name = "rejection_reason", columnDefinition = "TEXT")
    private String rejectionReason;

    @Column(name = "created_time")
    private LocalDateTime createdTime;

    @Column(name = "updated_time")
    private LocalDateTime updatedTime;
}
