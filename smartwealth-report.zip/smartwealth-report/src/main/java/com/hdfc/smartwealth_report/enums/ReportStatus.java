package com.hdfc.smartwealth_report.enums;

public enum ReportStatus {

    PROCESSING,
    READY,
    FAILED,
    COMPLETED
    
}
