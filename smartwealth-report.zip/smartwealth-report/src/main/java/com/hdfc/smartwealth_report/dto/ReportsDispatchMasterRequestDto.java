package com.hdfc.smartwealth_report.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.validation.constraints.NotNull;

import com.hdfc.smartwealth_report.enums.DispatchStatus;
import com.hdfc.smartwealth_report.enums.ReportType;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


/**
 * DTO used for CREATE and UPDATE of a Reports Dispatch Master record.
 * Maps to the two-panel form:
 *   Left  → Statement Dispatch Master (segment, effective date, dispatch date, frequency)
 *   Right → Statement Report Configuration Master (report type, report name, format, date range)
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReportsDispatchMasterRequestDto {
    
    // ── Statement Dispatch Master panel ──────────────────────────────────────

    /** ID of the segment (e.g. PSU, NRI DOMESTIC, RETAIL SEGMENT, MANAGED). */
    @NotNull(message = "Segment ID is required")
    private Long segmentId;

    /**
     * Effective date from which the dispatch schedule is active.
     * Maps to effective_date (DATE).
     */
    @NotNull(message = "Effective date is required")
    private LocalDate effectiveDate;

    /**
     * Day of the month on which dispatch should be triggered.
     * Maps to dispatch_date (INT).
     */
    private Integer dispatchDate;

    /**
     * Frequency of dispatch: encoded as integer.
     * 1 = Monthly, 3 = Quarterly, 6 = Half-Yearly, 12 = Yearly, 0 = On-Demand.
     * Maps to frequency (INT).
     */
    @NotNull(message = "Frequency is required")
    private Integer frequency;

    /**
     * Optional path to a CSV file uploaded by the user for custom recipient list.
     * Maps to custom_user_file_path (TEXT).
     */
    private String customUserFilePath;

    // ── Statement Report Configuration Master panel ───────────────────────────

    /** CLIENT or FAMILY. Maps to report_type (ENUM). */
    @NotNull(message = "Report type is required")
    private ReportType reportType;

    /**
     * FK to reports_master.id — the selected report (e.g. "Summary Report").
     * Maps to report_id.
     */
    @NotNull(message = "Report ID is required")
    private Long reportId;

    /**
     * Comma-separated formats selected: "PDF", "EXCEL", or "PDF,EXCEL".
     * Maps to report_format (VARCHAR 20).
     */
    @NotNull(message = "Report format is required")
    private String reportFormat;

    /**
     * "AS_ON_DATE" or "DATE_RANGE".
     * Maps to date_format_type (VARCHAR 50).
     */
    @NotNull(message = "Date format type is required")
    private String dateFormatType;

    /**
     * Used when dateFormatType = "AS_ON_DATE". The as-on date for the report.
     * Maps to report_from_date (DATETIME).
     */
    private LocalDateTime reportFromDate;

    /**
     * Used when dateFormatType = "DATE_RANGE". End of the report date range.
     * Maps to report_to_date (DATETIME).
     */
    private LocalDateTime reportToDate;

    /**
     * Initial status when saving — typically DRAFT or APPROVAL_PENDING.
     * Maps to status (ENUM).
     */
    private DispatchStatus status;

    /**
     * Maximum number of emails to send per day for this dispatch config.
     * Displayed as "Daily Email Limit" in the listing table.
     * Stored in the scheduler job record.
     */
    private Integer dailyEmailLimit;
}
