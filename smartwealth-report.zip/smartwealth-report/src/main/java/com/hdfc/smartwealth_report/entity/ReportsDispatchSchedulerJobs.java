package com.hdfc.smartwealth_report.entity;

//import jakarta.persistence.*;
import javax.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

import com.hdfc.smartwealth_report.enums.DispatchStatus;
import com.hdfc.smartwealth_report.enums.ReportType;

/**
 * Entity for tracking audit events related to email dispatch operations.
 * Maps to the 'reports_dispatch_scheduler_jobs' table.
 */
@Entity
@Table(name = "reports_dispatch_scheduler_jobs")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReportsDispatchSchedulerJobs {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "segment_id")
    private Long segmentId;

    @Column(name = "custom_user_file_path", columnDefinition = "TEXT")
    private String customUserFilePath;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "report_id", referencedColumnName = "id")
    private ReportsMaster report;

    @Enumerated(EnumType.STRING)
    @Column(name = "report_type", length = 20)
    private ReportType reportType;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", length = 30)
    private DispatchStatus status;

    @Column(name = "effective_date")
    private LocalDate effectiveDate;

    @Column(name = "dispatch_date")
    private Integer dispatchDate;

    @Column(name = "report_format", length = 20)
    private String reportFormat;

    @Column(name = "date_format_type", length = 50)
    private String dateFormatType;

    @Column(name = "report_from_date")
    private LocalDateTime reportFromDate;

    @Column(name = "report_to_date")
    private LocalDateTime reportToDate;

    @Column(name = "frequency")
    private Integer frequency;

    @Column(name = "created_time")
    private LocalDateTime createdTime;

    @Column(name = "updated_time")
    private LocalDateTime updatedTime;

    @Column(name = "stopped_time")
    private LocalDateTime stoppedTime;
}
