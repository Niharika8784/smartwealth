package com.hdfc.smartwealth_report.entity;

import java.time.LocalDateTime;

import com.hdfc.smartwealth_report.enums.ReportStatus;
import com.hdfc.smartwealth_report.enums.ReportType;

import javax.persistence.*;
//import jakarta.persistence.*;
//import jakarta.persistence.Id;
import javax.persistence.Id;
import lombok.Data;


// *******************
@Entity
@Data
public class ReportRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String requestId;

    @Enumerated(EnumType.STRING)
    private ReportStatus status;

    @Enumerated(EnumType.STRING)
    private ReportType reportType;

    private String sftpPath;

    private LocalDateTime createdAt;
    
}
