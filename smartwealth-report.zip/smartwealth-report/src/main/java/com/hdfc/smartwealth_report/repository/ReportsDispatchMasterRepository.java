package com.hdfc.smartwealth_report.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.hdfc.smartwealth_report.entity.ReportsDispatchMaster;
import com.hdfc.smartwealth_report.enums.DispatchStatus;
import com.hdfc.smartwealth_report.enums.ReportType;

@Repository
public interface ReportsDispatchMasterRepository extends JpaRepository<ReportsDispatchMaster, Long>{
    
//     /** All records for a given segment. */
//     List<ReportsDispatchMaster> findBySegmentId(Long segmentId);

//     /** All records matching a given status. */
//     List<ReportsDispatchMaster> findByStatus(DispatchStatus status);

//     /** All records matching a given report type. */
//     List<ReportsDispatchMaster> findByReportType(ReportType reportType);

//     /**
//      * Filtered listing query — all parameters are optional (null = ignore).
//      * Matches the filter dropdowns on the listing table (Report Type + Status).
//      */
//     @Query("""
//             SELECT rdm FROM ReportsDispatchMaster rdm
//             WHERE (:reportType IS NULL OR rdm.reportType = :reportType)
//               AND (:status     IS NULL OR rdm.status     = :status)
//             ORDER BY rdm.createdTime DESC
//             """)
//     List<ReportsDispatchMaster> findByFilters(
//             @Param("reportType") ReportType reportType,
//             @Param("status")     DispatchStatus status);

//     /** Check for duplicate: same segment + same report active at the same time. */
//     boolean existsBySegmentIdAndReport_IdAndStatusIn(
//             Long segmentId, Long reportId, List<DispatchStatus> activeStatuses);


  List<ReportsDispatchMaster> findBySegmentId(Long segmentId);

    List<ReportsDispatchMaster> findByStatus(DispatchStatus status);

    List<ReportsDispatchMaster> findByReportType(ReportType reportType);

    @Query("SELECT rdm FROM ReportsDispatchMaster rdm " +
           "WHERE (:reportType IS NULL OR rdm.reportType = :reportType) " +
           "AND (:status IS NULL OR rdm.status = :status) " +
           "ORDER BY rdm.createdTime DESC")
    List<ReportsDispatchMaster> findByFilters(
            @Param("reportType") ReportType reportType,
            @Param("status") DispatchStatus status);

    boolean existsBySegmentIdAndReport_IdAndStatusIn(
            Long segmentId, Long reportId, List<DispatchStatus> activeStatuses);
}
