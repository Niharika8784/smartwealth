package com.hdfc.smartwealth_report;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartwealthReportApplicationTests {

	@Test
	void contextLoads() {
	}

}
